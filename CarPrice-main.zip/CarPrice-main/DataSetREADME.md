# UsedCarDataset.csv
https://drive.google.com/file/d/16hkVhw4Yr2ywmYUCwhGCN0JTlUgzrhqV/view 
